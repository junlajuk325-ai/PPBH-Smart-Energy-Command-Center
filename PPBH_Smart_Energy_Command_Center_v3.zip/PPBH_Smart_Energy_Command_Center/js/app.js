async function load(){
document.getElementById('power').innerText='287.5 kW';
document.getElementById('today').innerText='327 kWh';
document.getElementById('saving').innerText='1,373 ฿';
document.getElementById('co2').innerText='153 kg';
}
load();